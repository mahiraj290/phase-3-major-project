# MedLens — local web demo

A user-facing web interface for the MedLens explainable AI class project. The included model is trained for a single binary diabetes benchmark task. The site presents a model output and feature-ablation explanation; it is **not** a general symptom checker or a medical diagnostic service.

## Open in VS Code

Open this folder, `MedLens_VSCode`, in VS Code. In the integrated PowerShell terminal:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:8000` in your browser. The server binds to localhost and does not save submitted values. Do not expose it to the internet or enter real patient information.

## Site sections

- **Assessment demo:** enter the eight fields required by the included benchmark model.
- **Model explanation:** view how changing each field to the training-set median changes this model's score.
- **Evaluation:** see the held-out metrics and model-selection summary generated for this dataset.

## Retrain the model

The project includes a fitted model so the site can start immediately. To regenerate the model and evaluation files from the included CSV, run `python src/train.py`.

## Project files

- `app.py` starts the local server.
- `backend/main.py` defines the local API and serves the site.
- `frontend/` contains the HTML, CSS, and browser-side JavaScript.
- `src/` contains preprocessing, training, and explanation code.
- `data/raw/diabetes.csv` is the included public benchmark copy; see `data/README.md` for provenance and limitations.
- `models/` and `reports/` contain the model and artifacts used by the site.

## Important limits

The dataset is small, historical, and narrowly sampled. The output is a model classification score, not an individual health assessment, diagnosis, or calibrated clinical probability. Explanations describe model behavior and do not establish cause. This project is for local academic demonstration only.
