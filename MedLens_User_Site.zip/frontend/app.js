const form = document.querySelector("#assessment-form");
const submitButton = document.querySelector("#submit-button");
const errorBox = document.querySelector("#form-error");
const emptyState = document.querySelector("#empty-state");
const resultContent = document.querySelector("#result-content");

const niceNames = {
  Pregnancies: "Pregnancies", Glucose: "Glucose", BloodPressure: "Blood pressure",
  SkinThickness: "Skin thickness", Insulin: "Insulin", BMI: "BMI",
  DiabetesPedigreeFunction: "Pedigree function", Age: "Age",
};
function showError(message) { errorBox.textContent = message; errorBox.hidden = false; }
function clearError() { errorBox.textContent = ""; errorBox.hidden = true; }
function formatScore(value) { return `${(value * 100).toFixed(1)}%`; }

function renderExplanation(items) {
  const container = document.querySelector("#explanation-list");
  container.replaceChildren();
  const max = Math.max(0.01, ...items.map((item) => Math.abs(item.score_change)));
  items.forEach((item) => {
    const row = document.createElement("div");
    row.className = "explanation-item";
    const name = document.createElement("span");
    name.className = "explanation-name";
    name.textContent = niceNames[item.feature] || item.feature;
    const track = document.createElement("span");
    track.className = "explanation-track";
    const fill = document.createElement("span");
    fill.classList.toggle("negative", item.score_change < 0);
    fill.style.width = `${Math.max(4, Math.abs(item.score_change) / max * 100)}%`;
    track.append(fill);
    const value = document.createElement("span");
    value.className = "explanation-value";
    value.textContent = `${item.score_change >= 0 ? "+" : ""}${item.score_change.toFixed(3)}`;
    row.append(name, track, value);
    container.append(row);
  });
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearError();
  submitButton.disabled = true;
  submitButton.textContent = "Reviewing benchmark case…";
  const payload = Object.fromEntries(new FormData(form).entries());
  for (const key of Object.keys(payload)) payload[key] = Number(payload[key]);
  try {
    const response = await fetch("/api/assess", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || "The assessment could not be completed.");
    document.querySelector("#score-value").textContent = formatScore(result.model_score_class_1);
    document.querySelector("#score-fill").style.width = `${Math.max(0, Math.min(100, result.model_score_class_1 * 100))}%`;
    document.querySelector("#class-result").textContent = `At the demonstration threshold (${result.threshold.toFixed(2)}), this model assigns class ${result.thresholded_model_class}. It is only the benchmark model's output.`;
    renderExplanation(result.explanation);
    emptyState.hidden = true;
    resultContent.hidden = false;
  } catch (error) {
    showError(error.message || "Could not reach the local MedLens server.");
  } finally {
    submitButton.disabled = false;
    submitButton.innerHTML = 'Run model demo <span aria-hidden="true">→</span>';
  }
});

async function loadMetrics() {
  try {
    const response = await fetch("/api/metrics");
    if (!response.ok) throw new Error("Evaluation metrics unavailable");
    const metrics = await response.json();
    document.querySelector("#metric-auc").textContent = metrics.roc_auc.toFixed(3);
    document.querySelector("#metric-accuracy").textContent = metrics.accuracy.toFixed(3);
    document.querySelector("#metric-recall").textContent = metrics.recall_sensitivity.toFixed(3);
    document.querySelector("#metric-specificity").textContent = metrics.specificity.toFixed(3);
    document.querySelector("#selected-model").textContent = metrics.selected_model;
    const cm = metrics.confusion_matrix;
    document.querySelector("#confusion-counts").textContent = `TN ${cm.true_negative} · FP ${cm.false_positive} · FN ${cm.false_negative} · TP ${cm.true_positive}`;
  } catch {
    document.querySelector("#selected-model").textContent = "Evaluation output unavailable";
    document.querySelector("#confusion-counts").textContent = "Run python src/train.py to regenerate results.";
  }
}
loadMetrics();

const noteButton = document.querySelector("#build-note");
const noteResult = document.querySelector("#visit-result");
let currentVisitNote = "";
noteButton.addEventListener("click", () => {
  const concern = document.querySelector("#concern-text").value.trim();
  const duration = document.querySelector("#duration").value;
  const extra = document.querySelector("#visit-extra").value.trim();
  if (!concern) {
    document.querySelector("#concern-text").focus();
    document.querySelector("#visit-summary").textContent = "Add a short description first, then create the note.";
    noteResult.hidden = false;
    return;
  }
  currentVisitNote = `Health concern: ${concern}\nDuration: ${duration}${extra ? `\nOther details or questions: ${extra}` : ""}`;
  document.querySelector("#visit-summary").textContent = currentVisitNote;
  document.querySelector("#copy-status").textContent = "";
  noteResult.hidden = false;
});

document.querySelector("#copy-note").addEventListener("click", async () => {
  if (!currentVisitNote) return;
  const status = document.querySelector("#copy-status");
  try {
    await navigator.clipboard.writeText(currentVisitNote);
    status.textContent = "Copied";
  } catch {
    status.textContent = "Select and copy the summary above";
  }
});
