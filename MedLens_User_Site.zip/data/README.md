# Dataset notes

The project includes `raw/diabetes.csv`, a headered copy of the Pima Indians Diabetes benchmark commonly distributed as a CSV mirror of the legacy UCI dataset. The source CSV used to prepare this copy was `https://raw.githubusercontent.com/jbrownlee/Datasets/master/pima-indians-diabetes.data.csv`.

The data documentation identifies the original owners as the National Institute of Diabetes and Digestive and Kidney Diseases and the donor as Vincent Sigillito at Johns Hopkins University. The benchmark contains 768 observations, eight numeric input features, and a binary outcome (500 class 0; 268 class 1). Feature columns are pregnancies, glucose, diastolic blood pressure, skin thickness, serum insulin, BMI, diabetes pedigree function, and age.

## Processing

The CSV copy only adds column names to the original rows. During training, zero measurements in glucose, blood pressure, skin thickness, insulin, and BMI are treated as missing and replaced by the median learned from each training fold. Zero is retained for pregnancies and pedigree function. The test split is never used to calculate imputation values.

## Provenance and use

- Legacy UCI dataset reference: https://archive.ics.uci.edu/ml/datasets/Pima+Indians+Diabetes
- Public CSV mirror: https://github.com/jbrownlee/Datasets/blob/master/pima-indians-diabetes.data.csv
- Dataset variable notes and original source attribution: https://github.com/jbrownlee/Datasets/blob/master/pima-indians-diabetes.names

The mirror's repository does not provide an explicit license for this individual file. This project includes it for an academic demonstration with attribution; confirm applicable terms before redistribution beyond the project. The original dataset is historically and demographically narrow. It must not be used as a clinical model or generalized to other populations.
