"""Local explanations for MedLens model outputs.

These explain the behavior of this benchmark model only; they are not causal
medical explanations. Optional SHAP and LIME imports are loaded on demand.
"""
from __future__ import annotations
import numpy as np
import pandas as pd


def feature_ablation(model, row: pd.DataFrame, background: pd.DataFrame) -> pd.DataFrame:
    """Compare the prediction with each feature replaced by its training median."""
    baseline = background.median(numeric_only=True)
    original_score = float(model.predict_proba(row)[:, 1][0])
    results = []
    for feature in row.columns:
        changed = row.copy()
        changed.loc[:, feature] = baseline[feature]
        changed_score = float(model.predict_proba(changed)[:, 1][0])
        results.append({"feature": feature, "score_change_when_set_to_median": original_score - changed_score})
    return pd.DataFrame(results).sort_values("score_change_when_set_to_median", key=lambda values: values.abs(), ascending=False)


def lime_explanation(pipeline, row: pd.DataFrame, background: pd.DataFrame, feature_names: list[str], num_features: int = 8):
    """Return a LIME explanation; requires the optional lime package."""
    from lime.lime_tabular import LimeTabularExplainer
    training = background[feature_names].copy()
    training = training.fillna(training.median())
    explainer = LimeTabularExplainer(
        training_data=training.to_numpy(dtype=float),
        feature_names=feature_names,
        class_names=["Class 0", "Class 1"],
        mode="classification",
        discretize_continuous=True,
        random_state=42,
    )
    predict_fn = lambda values: pipeline.predict_proba(pd.DataFrame(values, columns=feature_names))
    return explainer.explain_instance(row[feature_names].iloc[0].to_numpy(dtype=float), predict_fn, num_features=num_features)


def shap_values(pipeline, row: pd.DataFrame, background: pd.DataFrame):
    """Compute one-row SHAP values; requires the optional shap package."""
    import shap
    explainer = shap.Explainer(pipeline.predict_proba, background, algorithm="permutation")
    return explainer(row, max_evals=2 * row.shape[1] + 1)


