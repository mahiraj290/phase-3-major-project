"""Train, compare, and save MedLens benchmark classifiers."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, classification_report, confusion_matrix,
    f1_score, precision_score, recall_score, roc_auc_score, RocCurveDisplay,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC

from pipeline import FEATURES, TARGET, clean_features, load_dataset, make_preprocessor

SEED = 42


def candidates() -> dict[str, object]:
    return {
        "Logistic Regression": LogisticRegression(max_iter=2000, class_weight="balanced", random_state=SEED),
        "Random Forest": RandomForestClassifier(n_estimators=400, min_samples_leaf=3, class_weight="balanced", random_state=SEED, n_jobs=-1),
        "Gradient Boosting": GradientBoostingClassifier(n_estimators=120, learning_rate=0.05, max_depth=2, random_state=SEED),
        "RBF SVM": SVC(C=1.0, kernel="rbf", probability=True, class_weight="balanced", random_state=SEED),
    }


def train(data_path: Path, project_root: Path) -> dict:
    frame = load_dataset(data_path)
    X = clean_features(frame)
    y = frame[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, stratify=y, random_state=SEED
    )
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    comparison = []
    fitted = {}
    for name, estimator in candidates().items():
        pipeline = Pipeline([("preprocess", make_preprocessor()), ("model", estimator)])
        scores = cross_val_score(pipeline, X_train, y_train, cv=cv, scoring="roc_auc", n_jobs=1)
        pipeline.fit(X_train, y_train)
        comparison.append({"model": name, "cv_roc_auc_mean": float(scores.mean()), "cv_roc_auc_std": float(scores.std())})
        fitted[name] = pipeline
    comparison.sort(key=lambda row: row["cv_roc_auc_mean"], reverse=True)
    best_name = comparison[0]["model"]
    best = fitted[best_name]
    probs = best.predict_proba(X_test)[:, 1]
    preds = (probs >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_test, preds, labels=[0, 1]).ravel()
    metrics = {
        "selected_model": best_name,
        "selection_rule": "Highest mean five-fold stratified ROC-AUC on the training split",
        "threshold": 0.5,
        "test_rows": int(len(y_test)),
        "accuracy": float(accuracy_score(y_test, preds)),
        "balanced_accuracy": float(balanced_accuracy_score(y_test, preds)),
        "precision": float(precision_score(y_test, preds, zero_division=0)),
        "recall_sensitivity": float(recall_score(y_test, preds, zero_division=0)),
        "specificity": float(tn / (tn + fp)) if (tn + fp) else None,
        "f1": float(f1_score(y_test, preds, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_test, probs)),
        "confusion_matrix": {"true_negative": int(tn), "false_positive": int(fp), "false_negative": int(fn), "true_positive": int(tp)},
        "dataset_rows": int(len(frame)),
        "class_counts": {str(int(k)): int(v) for k, v in y.value_counts().sort_index().items()},
        "zero_values_marked_missing": {column: int((frame[column] == 0).sum()) for column in ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]},
        "limitations": ["Historical, narrow population; not representative of general clinical populations.", "A random holdout from this small dataset is an educational benchmark, not prospective validation.", "The model score is not calibrated clinical risk and the predicted class is not a diagnosis."],
    }
    reports_dir = project_root / "reports"
    models_dir = project_root / "models"
    reports_dir.mkdir(parents=True, exist_ok=True)
    models_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(comparison).to_csv(reports_dir / "model_comparison.csv", index=False)
    (reports_dir / "evaluation.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    (reports_dir / "classification_report.json").write_text(json.dumps(classification_report(y_test, preds, output_dict=True), indent=2), encoding="utf-8")
    bundle = {
        "pipeline": best,
        "model_name": best_name,
        "feature_names": FEATURES,
        "target_name": TARGET,
        "threshold": 0.5,
        "background": X_train.sample(min(80, len(X_train)), random_state=SEED),
        "comparison": comparison,
        "metrics": metrics,
    }
    joblib.dump(bundle, models_dir / "medlens_model.joblib")

    fig, ax = plt.subplots(figsize=(7.5, 5.2))
    RocCurveDisplay.from_predictions(y_test, probs, ax=ax, name=best_name, color="#147D83")
    ax.plot([0, 1], [0, 1], linestyle="--", color="#8A9498", linewidth=1)
    ax.set_title("Holdout ROC curve")
    fig.tight_layout()
    fig.savefig(reports_dir / "roc_curve.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    names = [row["model"] for row in comparison]
    values = [row["cv_roc_auc_mean"] for row in comparison]
    ax.barh(names[::-1], values[::-1], color="#147D83")
    ax.set_xlim(0.45, 1.0)
    ax.set_xlabel("Mean 5-fold ROC-AUC (training split)")
    ax.set_title("Model comparison")
    ax.grid(axis="x", alpha=0.2)
    fig.tight_layout()
    fig.savefig(reports_dir / "model_comparison.png", dpi=180)
    plt.close(fig)

    summary = {
        "rows": int(len(frame)), "columns": FEATURES + [TARGET],
        "class_counts": metrics["class_counts"],
        "missing_after_zero_correction": {key: int(value) for key, value in clean_features(frame).isna().sum().items()},
        "train_rows": int(len(y_train)), "test_rows": int(len(y_test)), "random_seed": SEED,
    }
    (reports_dir / "dataset_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({"selected_model": best_name, "metrics": metrics, "comparison": comparison}, indent=2))
    return metrics


def main() -> None:
    here = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=here / "data" / "raw" / "diabetes.csv")
    parser.add_argument("--output", type=Path, default=here)
    args = parser.parse_args()
    train(args.data, args.output.resolve())


if __name__ == "__main__":
    main()
