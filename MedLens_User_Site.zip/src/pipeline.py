"""Shared MedLens data and estimator pipeline."""
from __future__ import annotations

from pathlib import Path
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

FEATURES = [
    "Pregnancies",
    "Glucose",
    "BloodPressure",
    "SkinThickness",
    "Insulin",
    "BMI",
    "DiabetesPedigreeFunction",
    "Age",
]
TARGET = "Outcome"
ZERO_IS_MISSING = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]


def load_dataset(path: str | Path) -> pd.DataFrame:
    """Read the Pima CSV, accepting either the original headerless file or a named CSV."""
    frame = pd.read_csv(path)
    normalized = {str(column).strip().lower(): column for column in frame.columns}
    required = {name.lower() for name in FEATURES + [TARGET]}
    if not required.issubset(normalized):
        frame = pd.read_csv(path, header=None, names=FEATURES + [TARGET])
    else:
        frame = frame.rename(columns={normalized[name.lower()]: name for name in FEATURES + [TARGET]})
        frame = frame[FEATURES + [TARGET]]
    for column in FEATURES + [TARGET]:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    frame = frame.dropna(subset=[TARGET]).copy()
    frame[TARGET] = frame[TARGET].astype(int)
    invalid_labels = set(frame[TARGET].unique()) - {0, 1}
    if invalid_labels:
        raise ValueError(f"Outcome must contain only 0/1, got {sorted(invalid_labels)}")
    if frame.empty:
        raise ValueError("The dataset contains no usable rows.")
    return frame


def clean_features(frame: pd.DataFrame) -> pd.DataFrame:
    """Convert impossible zero measurements to missing values for imputation."""
    X = frame[FEATURES].copy()
    for column in ZERO_IS_MISSING:
        X.loc[X[column] == 0, column] = float("nan")
    return X


def make_preprocessor() -> ColumnTransformer:
    numeric = Pipeline([
        ("imputer", SimpleImputer(strategy="median", keep_empty_features=True)),
        ("scaler", StandardScaler()),
    ])
    return ColumnTransformer([("numeric", numeric, FEATURES)], verbose_feature_names_out=False)
