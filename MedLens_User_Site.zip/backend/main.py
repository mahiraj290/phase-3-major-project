"""Local-only FastAPI site for the MedLens diabetes benchmark demo."""
from __future__ import annotations

import json
from pathlib import Path
import sys

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from pipeline import FEATURES, clean_features
from explain import feature_ablation

MODEL_PATH = ROOT / "models" / "medlens_model.joblib"
METRICS_PATH = ROOT / "reports" / "evaluation.json"
FRONTEND_PATH = ROOT / "frontend"

app = FastAPI(title="MedLens local demo", docs_url="/api/docs", redoc_url=None)

try:
    bundle = joblib.load(MODEL_PATH)
except Exception as error:
    bundle = None
    MODEL_LOAD_ERROR = str(error)
else:
    MODEL_LOAD_ERROR = ""


class CaseInput(BaseModel):
    Pregnancies: int = Field(ge=0, le=20)
    Glucose: float = Field(ge=0, le=300)
    BloodPressure: float = Field(ge=0, le=200)
    SkinThickness: float = Field(ge=0, le=150)
    Insulin: float = Field(ge=0, le=1500)
    BMI: float = Field(ge=0, le=100)
    DiabetesPedigreeFunction: float = Field(ge=0, le=10)
    Age: int = Field(ge=21, le=120)


@app.get("/api/health")
def health():
    return {"ready": bundle is not None, "model": bundle.get("model_name") if bundle else None}


@app.get("/api/metrics")
def get_metrics():
    if not METRICS_PATH.exists():
        raise HTTPException(status_code=404, detail="Evaluation output is missing. Train the project model first.")
    return json.loads(METRICS_PATH.read_text(encoding="utf-8"))


@app.post("/api/assess")
def assess(case: CaseInput):
    if bundle is None:
        raise HTTPException(status_code=503, detail=f"Model bundle could not be loaded: {MODEL_LOAD_ERROR}")
    case_values = case.model_dump() if hasattr(case, "model_dump") else case.dict()
    raw = pd.DataFrame([case_values], columns=FEATURES)
    row = clean_features(raw)
    model = bundle["pipeline"]
    score = float(model.predict_proba(row)[:, 1][0])
    threshold = float(bundle.get("threshold", 0.5))
    explanation = feature_ablation(model, row, bundle["background"])
    items = [
        {"feature": str(record["feature"]), "score_change": float(record["score_change_when_set_to_median"])}
        for record in explanation.to_dict(orient="records")
    ]
    return {
        "model_score_class_1": score,
        "thresholded_model_class": int(score >= threshold),
        "threshold": threshold,
        "model_name": bundle.get("model_name", "Unknown"),
        "explanation": items,
        "disclaimer": "Educational benchmark output only. This is not a diagnosis or a calibrated clinical risk estimate.",
    }


@app.get("/")
def index():
    return FileResponse(FRONTEND_PATH / "index.html")


app.mount("/", StaticFiles(directory=FRONTEND_PATH), name="frontend")

